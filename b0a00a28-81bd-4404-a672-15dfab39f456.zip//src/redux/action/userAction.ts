import axios from "axios";

import { FETCH_USER, INC_COUNT, REMOVE_MESSAGE } from "./actionTypes";

// export function getUser(dispatch: any) {
//   const fn = async () => {
//     try {
//       const { data } = await axios.get("data.json");
//       dispatch({ type: FETCH_USER, payload: data });
//     } catch (err) {
//       console.log(err);
//     }
//   };
//   fn();
// }

//Load User
export const getUser: any = () => async (dispatch: any) => {
  try {
    const { data } = await axios.get("/data.json");

    dispatch({
      type: FETCH_USER,
      payload: data //the data is the user ..send to reducer
    });
  } catch (err) {
    console.log(err);
  }
};

// export function getUser(dispatch: any) {
//   const fn = async () => {
//     try {
//       const { data } = await axios.get("data.json");
//       dispatch({ type: FETCH_USER, payload: data });
//     } catch (err) {
//       console.log(err);
//     }
//   };
//   fn();
// }

export const incCountReadMeassges = (id: string | undefined) => {
  return {
    type: INC_COUNT,
    payload: id
  };
};

export const removeMsg = (id: string | undefined) => {
  return {
    type: REMOVE_MESSAGE,
    payload: id
  };
};
