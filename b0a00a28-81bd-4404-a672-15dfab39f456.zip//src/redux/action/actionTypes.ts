export const FETCH_USER = "FETCH_USER";
export const REMOVE_MESSAGE = "REMOVE_MESSAGE";
export const INC_COUNT = "INC_COUNT";
