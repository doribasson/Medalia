import { combineReducers, createStore, applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import thunk from "redux-thunk";

import { IData } from "../model";
import userReducer from "./reducer/userReducer";

const middleware = [thunk];

const reducers = combineReducers({ user: userReducer });
export const store = createStore(
  reducers,
  composeWithDevTools(applyMiddleware(...middleware))
);

export interface IRootState {
  user: IData;
}
