// import { v4 as uuidv4 } from "uuid";
import { IUserActionModel, IUser, IMessage, IData } from "../../model";
import { FETCH_USER, INC_COUNT, REMOVE_MESSAGE } from "../action/actionTypes";

const initalState: IData = {
  userData: <IUser>{},
  loading: true,
  error: {}
};

const userReducer = (state = initalState, action: IUserActionModel) => {
  const { type, payload } = action;
  switch (type) {
    case FETCH_USER:
      const updateCountReadMeassges = payload?.messages?.reduce(
        (acc: number, msg: IMessage) => {
          if (msg.isRead) {
            acc = acc + 1;
          }
          return acc;
        },
        0
      );
      return {
        ...state,
        loading: false,
        userData: { ...payload, countReadMeassges: updateCountReadMeassges }
      };

    case REMOVE_MESSAGE:
      const removeMsg = state.userData.messages.filter(
        (msg: IMessage) => msg.id !== payload
      );
      const newCountReadMeassges = state.userData.messages.reduce(
        (acc: number, msg: IMessage) => {
          if (msg.id === payload && msg.isRead) {
            acc = acc - 1;
          }
          return acc;
        },
        state.userData.countReadMeassges
      );
      return {
        ...state,
        userData: {
          ...state.userData,
          messages: removeMsg,
          countReadMeassges: newCountReadMeassges
        }
      };

    case INC_COUNT:
      const updateIsRead = state.userData.messages.map((msg: IMessage) =>
        msg.id === payload ? { ...msg, isRead: true } : msg
      );
      return {
        ...state,
        userData: {
          ...state.userData,
          messages: updateIsRead,
          countReadMeassges: state.userData.countReadMeassges + 1
        }
      };
    default:
      return state;
  }
};
export default userReducer;
