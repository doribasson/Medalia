import { lazy, Suspense } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

const Home = lazy(() => import("../../screen/home/Home"));
const Messages = lazy(() => import("../../screen/messages/Messages"));
const Message = lazy(() => import("../../screen/message/Message"));

// import Home from "../../screen/home/Home";
// import Messages from "../../screen/messages/Messages";
// import Message from "../../screen/message/Message";
export default function AllRoutes() {
  return (
    <Router>
      <Suspense fallback={"Loading"}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/messages/:messageId" element={<Message />} />
          <Route path="*" element={"not found"} />
        </Routes>
      </Suspense>
    </Router>
  );
}
