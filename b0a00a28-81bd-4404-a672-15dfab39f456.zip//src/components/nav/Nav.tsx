import { Link } from "react-router-dom";

import "./nav.css";

interface props {
  navigates: any;
}

function Nav({ navigates }: props) {
  const leftNavImg = navigates?.leftNav?.img;
  const rightNavImg = navigates?.rightNav?.img;
  const leftNavNavigate = navigates?.leftNav?.navigate || {};
  const rightNavNavigate = navigates?.rightNav?.navigate || {};

  return (
    <nav className="nav_container">
      <span>
        <Link className="icons" to={leftNavNavigate}>
          {leftNavImg}
        </Link>
      </span>
      <span>
        <Link className="icons" to={rightNavNavigate}>
          {rightNavImg}
        </Link>
      </span>
    </nav>
  );
}

export default Nav;
