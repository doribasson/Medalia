import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { FaCheckCircle, FaCircle, FaTrashAlt } from "react-icons/fa";

import { IMessage } from "../../model";
import { incCountReadMeassges, removeMsg } from "../../redux/action/userAction";
import "./card.css";

interface props {
  item: IMessage;
  navigateToMsg: string;
}

function Card({
  navigateToMsg,
  item: { subject, content, id, isRead }
}: props) {
  const dispatch = useDispatch();

  let navigate = useNavigate();

  const navigateToMsgId = () => {
    if (id) {
      navigate(navigateToMsg);
    }
    if (!isRead) {
      dispatch(incCountReadMeassges(id));
    }
  };

  const handleRmvMsg = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    dispatch(removeMsg(id));
  };

  return (
    <div onClick={() => navigateToMsgId()} className="card_container">
      <span className={isRead ? "readMsgdClass" : "notReadMsgClass"}>
        {isRead ? <FaCheckCircle /> : <FaCircle />}
      </span>
      <span className="card_subject">{subject}</span>
      <p className="content">{content}</p>
      <span className="trash" onClick={handleRmvMsg}>
        <FaTrashAlt />
      </span>
    </div>
  );
}

export default Card;
