import { useState, useEffect, useCallback } from "react";
import { useSelector } from "react-redux";
import { FaArrowAltCircleLeft } from "react-icons/fa";
import { debounce } from "../../helper/debounce";
import { IRootState } from "../../redux/store";
import Card from "../../components/card/Card";
import Nav from "../../components/nav/Nav";
import SearchBar from "../../components/searchbar/SearchBar";
import "./messages.css";
import { IData, IMessage } from "../../model";

function Messages() {
  const data: IData = useSelector((state: IRootState) => state.user);

  const [searchTerm, setSearchTerm] = useState<string>("");
  const [filteredMsg, setFilteredMsg] = useState<IMessage[]>(
    data.userData.messages
  );

  console.log(data.userData);
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const optimizeDebounce = useCallback(debounce(handleChange, 500), []);

  useEffect(() => {
    const searchByContent = data.userData.messages?.filter((it) => {
      let temp = it.subject + " " + it.content;
      if (temp.toLowerCase().includes(searchTerm.toLowerCase())) {
        return it;
      }
      return null;
    });
    setFilteredMsg(searchByContent);
  }, [data.userData.messages, searchTerm]);

  return (
    <div className="global_container">
      <Nav
        navigates={{
          leftNav: { img: <FaArrowAltCircleLeft />, navigate: "/" }
        }}
      />
      <SearchBar handleChange={optimizeDebounce} />
      <br />
      <div className="messages_container">
        {filteredMsg?.length > 0 &&
          filteredMsg?.map((msg: IMessage) => {
            return <Card key={msg.id} item={msg} navigateToMsg={`${msg.id}`} />;
          })}
      </div>
    </div>
  );
}

export default Messages;
