import { useState } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";

import "./home.css";
import { IRootState } from "../../redux/store";
import { IMessage } from "../../model";
import Card from "../../components/card/Card";

function Home() {
  const user: any = useSelector((state: IRootState) => state.user);
  const {
    userData: { name, countReadMeassges, messages }
  } = user || {};

  const [isShowUnreadMsg, setIsShowUnreadMsg] = useState<boolean>(false);

  const countUnreadMessage: number | null = messages?.length
    ? messages.length - countReadMeassges
    : null;

  const unreadMessage = messages?.filter(
    (msg: IMessage) => msg.isRead === false
  );

  return (
    <div className="global_container">
      <section>
        <strong className="title">{`Hello ${name}`}</strong>
        <p>
          {countUnreadMessage || messages.length > 0
            ? `You have ${countUnreadMessage} unread messages out of ${messages?.length} total`
            : "You dont have messages"}
        </p>
      </section>
      <div className="button_container">
        <Link to={messages.length > 0 ? "messages" : ""}>
          <button onClick={() => setIsShowUnreadMsg(!isShowUnreadMsg)}>
            all messages
          </button>
        </Link>
        <button onClick={() => setIsShowUnreadMsg(!isShowUnreadMsg)}>
          unread messages
        </button>
      </div>
      <br />
      <div>
        {isShowUnreadMsg &&
          messages.length > 0 &&
          unreadMessage.map((msg: IMessage) => (
            <Card
              key={msg.id}
              item={msg}
              navigateToMsg={`messages/${msg.id}`}
            />
          ))}
      </div>
    </div>
  );
}

export default Home;
