import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { IRootState, store } from "../redux/store";

import "../styles.css";
import { getUser } from "../redux/action/userAction";
import AllRoutes from "../components/routes/AllRoutes";

export default function App() {
  // const dispatch = useDispatch();
  const user = useSelector((state: IRootState) => state.user);

  const { loading } = user || {};

  useEffect(() => {
    store.dispatch(getUser());
  }, []);

  if (loading) {
    return <h1>Loading...</h1>;
  }

  return <AllRoutes />;
}
