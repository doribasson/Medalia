import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import { FaArrowAltCircleLeft, FaHome } from "react-icons/fa";

import "./message.css";
import { IRootState } from "../../redux/store";
import { IMessage } from "../../model";
import Nav from "../../components/nav/Nav";

function Message() {
  let { messageId } = useParams();

  const user = useSelector((state: IRootState) => state.user);
  const {
    userData: { messages }
  } = user || {};

  const getCurrentMsg: IMessage | undefined = messages?.find(
    (msg: IMessage) => msg.id === messageId
  );

  const { content, subject } = getCurrentMsg || {};

  return (
    <div className="global_container">
      <Nav
        navigates={{
          leftNav: { img: <FaArrowAltCircleLeft />, navigate: "/messages" },
          rightNav: { img: <FaHome />, navigate: "/" }
        }}
      />

      <h2>{subject}</h2>
      {!getCurrentMsg ? (
        "no such"
      ) : (
        <p className="content_message">{content}</p>
      )}
    </div>
  );
}

export default Message;
